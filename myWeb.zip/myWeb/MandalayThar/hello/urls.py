from django.urls import path

from . import views

urlpatterns = [
    path('', views.Print_Hello, name = 'My Hello')
]
